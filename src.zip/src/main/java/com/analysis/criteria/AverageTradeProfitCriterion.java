/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.analysis.criteria;

import java.util.OptionalDouble;
import org.ta4j.core.TimeSeries;
import org.ta4j.core.Trade;
import org.ta4j.core.TradingRecord;
import org.ta4j.core.analysis.criteria.AbstractAnalysisCriterion;
import org.ta4j.core.num.Num;
import org.ta4j.core.num.PrecisionNum;

/**
 *
 * @author aanpilov
 */
public class AverageTradeProfitCriterion extends AbstractAnalysisCriterion {

    @Override
    public Num calculate(TimeSeries series, Trade trade) {
        Num profit;

        if (trade.getEntry().isBuy()) {
            profit = trade.getExit().getPrice().dividedBy(trade.getEntry().getPrice());
        } else {
            profit = trade.getEntry().getPrice().dividedBy(trade.getExit().getPrice());
        }
        
        return profit.multipliedBy(PrecisionNum.valueOf(100000)).minus(PrecisionNum.valueOf(100000)).dividedBy(PrecisionNum.valueOf(1000));
    }

    @Override
    public Num calculate(TimeSeries series, TradingRecord tradingRecord) {
        double average = tradingRecord.getTrades().stream().map(trade -> calculate(series, trade)).mapToDouble(n -> n.doubleValue()).average().getAsDouble();
        
        return PrecisionNum.valueOf(average);
    }

    @Override
    public boolean betterThan(Num criterionValue1, Num criterionValue2) {
        return criterionValue1.isGreaterThan(criterionValue2);
    }
    
}
