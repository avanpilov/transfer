/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.analysis.criteria;

import java.math.BigDecimal;
import org.ta4j.core.TimeSeries;
import org.ta4j.core.Trade;
import org.ta4j.core.TradingRecord;
import org.ta4j.core.analysis.criteria.AbstractAnalysisCriterion;
import org.ta4j.core.num.Num;
import org.ta4j.core.num.PrecisionNum;

/**
 *
 * @author aanpilov
 */
public class TotalProfitCriterion extends AbstractAnalysisCriterion {

    @Override
    public Num calculate(TimeSeries series, TradingRecord tradingRecord) {
        Num value = PrecisionNum.valueOf(1);
        for (Trade trade : tradingRecord.getTrades()) {
            value = value.multipliedBy(calculateProfit(series, trade));
        }
        return value;
    }

    @Override
    public Num calculate(TimeSeries series, Trade trade) {
        return calculateProfit(series, trade);
    }

    @Override
    public boolean betterThan(Num criterionValue1, Num criterionValue2) {
        return criterionValue1.isGreaterThanOrEqual(criterionValue2);
    }

    /**
     * Calculates the profit of a trade (Buy and sell).
     * @param series a time series
     * @param trade a trade
     * @return the profit of the trade
     */
    private Num calculateProfit(TimeSeries series, Trade trade) {
        Num profit = PrecisionNum.valueOf(BigDecimal.ONE);
        if (trade.isClosed()) {
            Num exitClosePrice = trade.getExit().getPrice();
            Num entryClosePrice = trade.getEntry().getPrice();

            if (trade.getEntry().isBuy()) {
                profit = exitClosePrice.dividedBy(entryClosePrice);
            } else {
                profit = entryClosePrice.dividedBy(exitClosePrice);
            }
        }
        return profit;
    }

}