/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com;

import com.analysis.CashFlow;
import com.analysis.criteria.AverageTradeProfitCriterion;
import com.analysis.criteria.RewardTradeRiskRationCriterion;
import com.analysis.criteria.TotalProfitCriterion;
import com.loader.FinamCsvTicksLoader;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.stream.Collectors;
import org.ta4j.core.BaseTimeSeries;
import org.ta4j.core.BaseTradingRecord;
import org.ta4j.core.Order;
import org.ta4j.core.Rule;
import org.ta4j.core.TimeSeries;
import org.ta4j.core.Trade;
import org.ta4j.core.TradingRecord;
import org.ta4j.core.analysis.criteria.AverageProfitableTradesCriterion;
import org.ta4j.core.analysis.criteria.MaximumDrawdownCriterion;
import org.ta4j.core.analysis.criteria.RewardRiskRatioCriterion;
import org.ta4j.core.indicators.SMAIndicator;
import org.ta4j.core.indicators.StochasticOscillatorKIndicator;
import org.ta4j.core.num.Num;
import org.ta4j.core.num.PrecisionNum;
import org.ta4j.core.trading.rules.OverIndicatorRule;
import org.ta4j.core.trading.rules.UnderIndicatorRule;
import rx.Observable;
import rx.schedulers.Schedulers;
import rx.subjects.PublishSubject;

/**
 *
 * @author aanpilov
 */
public class StochTest {
    private int unstable, positionSize = 0;
    private Num catchedMove = PrecisionNum.valueOf(0);    
    
    private final TimeSeries timeSeries;
    private Rule enterLongRule, enterShortRule, exitLongRule, exitShortRule;   
    private TradingRecord longTradingRecord = new BaseTradingRecord(Order.OrderType.BUY);
    private TradingRecord shortTradingRecord = new BaseTradingRecord(Order.OrderType.SELL);

    public StochTest(int unstable, int s, int k, int d, TimeSeries timeSeries) {
        this.unstable = unstable;
        this.timeSeries = timeSeries;
        
        StochasticOscillatorKIndicator stochIndicator = new StochasticOscillatorKIndicator(timeSeries, s);
        SMAIndicator kIndicator = new SMAIndicator(stochIndicator, k);
        SMAIndicator dIndicator = new SMAIndicator(kIndicator, d);
        
        exitShortRule = new OverIndicatorRule(kIndicator, dIndicator).and(new OverIndicatorRule(kIndicator, 20));
        
        exitLongRule = new UnderIndicatorRule(kIndicator, dIndicator).and(new UnderIndicatorRule(kIndicator, 80));
        
        enterShortRule = exitLongRule.or(new UnderIndicatorRule(kIndicator, 20));
        
        enterLongRule = exitShortRule.or(new OverIndicatorRule(kIndicator, 80));
    }
    
    public void onNext(int index) {
        if(index < unstable) {
            return;
        }
        
        if (exitLongRule.isSatisfied(index) && positionSize > 0) {            
            positionSize--;
            longTradingRecord.exit(index, timeSeries.getBar(index).getClosePrice(), PrecisionNum.valueOf(1));
        }
        if (exitShortRule.isSatisfied(index) && positionSize < 0) {            
            positionSize++;            
            shortTradingRecord.exit(index, timeSeries.getBar(index).getClosePrice(), PrecisionNum.valueOf(1));
        }
        if (enterLongRule.isSatisfied(index) && positionSize == 0) {            
            positionSize++;            
            longTradingRecord.enter(index, timeSeries.getBar(index).getClosePrice(), PrecisionNum.valueOf(1));
        }
        if (enterShortRule.isSatisfied(index) && positionSize == 0) {            
            positionSize--;            
            shortTradingRecord.enter(index, timeSeries.getBar(index).getClosePrice(), PrecisionNum.valueOf(1));
        }
    }
    
    public TradingRecord getAccumulatedTradingRecord() {
        if(!longTradingRecord.isClosed()) {
            longTradingRecord.exit(timeSeries.getEndIndex(), timeSeries.getLastBar().getClosePrice(), PrecisionNum.valueOf(1));
        }
        if(!shortTradingRecord.isClosed()) {
            shortTradingRecord.exit(timeSeries.getEndIndex(), timeSeries.getLastBar().getClosePrice(), PrecisionNum.valueOf(1));
        }
        
        List<Order> orders = new ArrayList<>();        
        orders.addAll(longTradingRecord.getTrades().stream().map(t -> t.getEntry()).collect(Collectors.toList()));
        orders.addAll(longTradingRecord.getTrades().stream().map(t -> t.getExit()).collect(Collectors.toList()));
        orders.addAll(shortTradingRecord.getTrades().stream().map(t -> t.getEntry()).collect(Collectors.toList()));
        orders.addAll(shortTradingRecord.getTrades().stream().map(t -> t.getExit()).collect(Collectors.toList()));        
        Map<Integer, List<Order>> ordersCollection = orders.stream().collect(Collectors.groupingBy(o -> o.getIndex()));
        
        final List<Order> resultOrders = new ArrayList<>();
        ordersCollection.keySet().stream().sorted().map(k -> resultOrders.addAll(ordersCollection.get(k))).collect(Collectors.toList());
        
        if(resultOrders.isEmpty()) {
            return new BaseTradingRecord();
        } else {
            return new BaseTradingRecord(resultOrders.toArray(new Order[]{}));
        }
    }
    
    public Num getTotalProfit() {
        return new TotalProfitCriterion().calculate(timeSeries, getAccumulatedTradingRecord());
    }
    
    public Num getProfitableRatio() {
        return new AverageProfitableTradesCriterion().calculate(timeSeries, getAccumulatedTradingRecord());
    }
    
    public Num getCashFlowProfit() {
        return new CashFlow(timeSeries, getAccumulatedTradingRecord()).getValue(timeSeries.getEndIndex());
    }
    
    public static void main(String[] args) throws Exception {
        TimeSeries finamSeries = FinamCsvTicksLoader.loadSeries(new File("src/test/resources/SBER_2018_1H.csv"));
        TimeSeries series = new BaseTimeSeries("test");
        PublishSubject<Integer> indexObservable = PublishSubject.create();
        
        Map<String, StochTest> patients = new TreeMap<>();
        int maxS = 9, maxK = 9, maxD = 4;
        int unstable = maxS + maxK + maxD - 2;
        
        for (int s = 9; s <= maxS; s++) {
            for (int k = 9; k <= Math.min(maxK, s); k++) {
                for (int d = 4; d <= Math.min(maxD, k); d++) {
                    String key = s + "-" + k + "-" + d;
                    StochTest test = new StochTest(unstable, s, k, d, series);
                    patients.put(key, test);
                    
                    indexObservable.subscribe(i -> test.onNext(i));                    
                }
            }
        }
        
        for (int i = 0; i < finamSeries.getBarCount(); i++) {
            series.addBar(finamSeries.getBar(i));
            indexObservable.onNext(i);
        }
        
        for (String key : patients.keySet()) {
            System.out.println(key + ":\t" + patients.get(key).getTotalProfit());
            System.out.println("Max DD:\t" + new MaximumDrawdownCriterion().calculate(series, patients.get(key).getAccumulatedTradingRecord()));
            System.out.println(key + ":\t" + new RewardTradeRiskRationCriterion().calculate(series, patients.get(key).getAccumulatedTradingRecord()));
        }
    }
}
