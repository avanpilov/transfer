/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.loader;

import au.com.bytecode.opencsv.CSVReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import org.slf4j.LoggerFactory;
import org.ta4j.core.Bar;
import org.ta4j.core.BaseBar;
import org.ta4j.core.BaseTimeSeries;
import org.ta4j.core.TimeSeries;
import org.ta4j.core.num.PrecisionNum;

/**
 *
 * @author aanpilov
 */
public class FinamCsvTicksLoader {
    private static final org.slf4j.Logger log = LoggerFactory.getLogger("com.loader");
    private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyyMMdd HH:mm:ss");
    
    public static TimeSeries loadSeries(File file) throws Exception {
        InputStream stream = new FileInputStream(file);

        List<Bar> ticks = new ArrayList<>();        

        CSVReader csvReader = new CSVReader(new InputStreamReader(stream, Charset.forName("UTF-8")), ',', '"', 1);
        try {
            String[] line;
            while ((line = csvReader.readNext()) != null) {
                String dateStr = line[0] + " " + line[1];
                ZonedDateTime date = LocalDateTime.parse(dateStr, DateTimeFormatter.ofPattern("yyyyMMdd HH:mm:ss")).atZone(ZoneId.systemDefault());
                double open = Double.parseDouble(line[2]);
                double high = Double.parseDouble(line[3]);
                double low = Double.parseDouble(line[4]);
                double close = Double.parseDouble(line[5]);
                double volume = Double.parseDouble(line[6]);

                ticks.add(new BaseBar(date, open, high, low, close, volume, PrecisionNum::valueOf));
            }
        } catch (IOException ioe) {
            log.error("Unable to load ticks from CSV", ioe);
        } catch (NumberFormatException nfe) {
            log.error("Error while parsing value", nfe);
        }

        return new BaseTimeSeries("finam_ticks", ticks);
    }    
    
}
