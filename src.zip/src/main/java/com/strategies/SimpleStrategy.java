/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.strategies;

import com.ShiftedTimeSeriesProxyHandler;
import com.analysis.criteria.TotalProfitCriterion;
import com.indicator.StandardDeviationPercentIndicator;
import com.scale.ScaledTimeSeriesProxyHandler;
import com.loader.FinamCsvTicksLoader;
import com.scale.ScaledRule;
import com.scale.ScaledTimeSeries;
import org.ta4j.core.BaseTimeSeries;
import org.ta4j.core.BaseTradingRecord;
import org.ta4j.core.Order;
import org.ta4j.core.Rule;
import org.ta4j.core.TimeSeries;
import org.ta4j.core.Trade;
import org.ta4j.core.TradingRecord;
import org.ta4j.core.analysis.criteria.AverageProfitCriterion;
import org.ta4j.core.analysis.criteria.AverageProfitableTradesCriterion;
import org.ta4j.core.analysis.criteria.BuyAndHoldCriterion;
import org.ta4j.core.analysis.criteria.LinearTransactionCostCriterion;
import org.ta4j.core.analysis.criteria.MaximumDrawdownCriterion;
import org.ta4j.core.analysis.criteria.NumberOfTradesCriterion;
import org.ta4j.core.analysis.criteria.RewardRiskRatioCriterion;
import org.ta4j.core.analysis.criteria.VersusBuyAndHoldCriterion;
import org.ta4j.core.indicators.StochasticOscillatorKIndicator;
import org.ta4j.core.indicators.SMAIndicator;
import org.ta4j.core.indicators.helpers.ClosePriceIndicator;
import org.ta4j.core.trading.rules.InPipeRule;
import org.ta4j.core.trading.rules.OverIndicatorRule;
import org.ta4j.core.trading.rules.UnderIndicatorRule;
import java.io.File;
import java.lang.reflect.Proxy;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import org.ta4j.core.Bar;
import org.ta4j.core.num.PrecisionNum;

/**
 *
 * @author aanpilov
 */
public class SimpleStrategy {
    private final TimeSeries timeSeries;
    private final ScaledTimeSeries parentTimeSeries;
    private int unstablePeriod;
    private Rule enterLongRule;
    private Rule enterShortRule;
    private Rule exitLongRule;    
    private Rule exitShortRule;    

    public SimpleStrategy(TimeSeries timeSeries) {
        this.timeSeries = (TimeSeries) Proxy.newProxyInstance(TimeSeries.class.getClassLoader(), new Class<?>[]{TimeSeries.class}, new ShiftedTimeSeriesProxyHandler(timeSeries));
        parentTimeSeries = (com.scale.ScaledTimeSeries)Proxy.newProxyInstance(TimeSeries.class.getClassLoader(), new Class<?>[]{com.scale.ScaledTimeSeries.class}, new ScaledTimeSeriesProxyHandler(timeSeries, ChronoUnit.DAYS));
        initRules();
    }

    private void initRules() {
        unstablePeriod = 81;
        
        StochasticOscillatorKIndicator parentStochIndicator = new StochasticOscillatorKIndicator(parentTimeSeries, 5);        
        SMAIndicator parentKIndicator = new SMAIndicator(parentStochIndicator, 4);
        SMAIndicator parentDIndicator = new SMAIndicator(parentKIndicator, 3);
        
        OverIndicatorRule parentDeviationRule = new OverIndicatorRule(new StandardDeviationPercentIndicator(new ClosePriceIndicator(parentTimeSeries), 13), 0.5);
        
        Rule parentLongEnterRule = parentDeviationRule.and(new InPipeRule(parentKIndicator, 80, 20)
                                .and(new OverIndicatorRule(parentKIndicator, parentDIndicator))
                               .or(new OverIndicatorRule(parentKIndicator, 80)));
        ScaledRule parentLongEnterRuleWrapper = new ScaledRule(parentLongEnterRule, parentTimeSeries);
        
        Rule parentShortEnterRule = parentDeviationRule.and(new InPipeRule(parentKIndicator, 80, 20)
                                .and(new UnderIndicatorRule(parentKIndicator, parentDIndicator))
                               .or(new UnderIndicatorRule(parentKIndicator, 20)));
        ScaledRule parentShortEnterRuleWrapper = new ScaledRule(parentShortEnterRule, parentTimeSeries);
        
        StochasticOscillatorKIndicator stochIndicator = new StochasticOscillatorKIndicator(timeSeries, 8);
        SMAIndicator kIndicator = new SMAIndicator(stochIndicator, 5);
        SMAIndicator dIndicator = new SMAIndicator(kIndicator, 3);
        
        exitShortRule = new OverIndicatorRule(kIndicator, dIndicator).and(new OverIndicatorRule(kIndicator, 20));
        
        exitLongRule = new UnderIndicatorRule(kIndicator, dIndicator).and(new UnderIndicatorRule(kIndicator, 80));
        
        enterShortRule = exitLongRule.or(new UnderIndicatorRule(kIndicator, 20));
        
        enterLongRule = exitShortRule.or(new OverIndicatorRule(kIndicator, 80));
    }
    
    public boolean shouldEnterLong(int index) {
        if (isUnstableAt(index)) {
            return false;
        }
        return enterLongRule.isSatisfied(index);
    }
    
    public boolean shouldEnterShort(int index) {
        if (isUnstableAt(index)) {
            return false;
        }
        return enterShortRule.isSatisfied(index);
    }
    
    public boolean shouldExitLong(int index) {
        if (isUnstableAt(index)) {
            return false;
        }
        return exitLongRule.isSatisfied(index);
    }
    
    public boolean shouldExitShort(int index) {
        if (isUnstableAt(index)) {
            return false;
        }
        return exitShortRule.isSatisfied(index);
    }
    
    public boolean isUnstableAt(int index) {
        return index < unstablePeriod;
    }
    
    public static void main(String[] args) throws Exception {
        TimeSeries finamSeries = FinamCsvTicksLoader.loadSeries(new File("src/test/resources/SBER_2018_1H.csv"));
        TimeSeries series = new BaseTimeSeries("test");
        
        SimpleStrategy strategy = new SimpleStrategy(series);
        TradingRecord longTradingRecord = new BaseTradingRecord(Order.OrderType.BUY);
        TradingRecord shortTradingRecord = new BaseTradingRecord(Order.OrderType.SELL);
        
        int positionSize = 0;
        
        for (int i = 0; i < finamSeries.getBarCount(); i++) {
            Bar newTick = finamSeries.getBar(i);
            
            series.addBar(newTick);

            int endIndex = series.getEndIndex();
            if(strategy.shouldExitLong(endIndex) && positionSize > 0) {
                positionSize--;
                System.out.println("Strategy should EXIT_LONG on " + newTick.getEndTime());
                longTradingRecord.exit(endIndex, newTick.getClosePrice(), PrecisionNum.valueOf(1));
            }
            if(strategy.shouldExitShort(endIndex) && positionSize < 0) {
                positionSize++;
                System.out.println("Strategy should EXIT_SHORT on " + newTick.getEndTime());
                shortTradingRecord.exit(endIndex, newTick.getClosePrice(), PrecisionNum.valueOf(1));
            }
            if (strategy.shouldEnterLong(endIndex) && positionSize <= 0) {
                positionSize++;                
                System.out.println("Strategy should ENTER_LONG on " + newTick.getEndTime());
                longTradingRecord.enter(endIndex, newTick.getClosePrice(), PrecisionNum.valueOf(1));
            } 
            if (strategy.shouldEnterShort(endIndex) && positionSize >= 0) {
                positionSize--;                
                System.out.println("Strategy should ENTER_SHORT on " + newTick.getEndTime());
                shortTradingRecord.enter(endIndex, newTick.getClosePrice(), PrecisionNum.valueOf(1));
            }
        }
        
        List<Order> orders = new ArrayList<>();
        for(Trade trade : longTradingRecord.getTrades()) {
            orders.add(trade.getEntry());
            orders.add(trade.getExit());
        }
        
        for(Trade trade : shortTradingRecord.getTrades()) {
            orders.add(trade.getEntry());
            orders.add(trade.getExit());
        }
        Order[] arrayOrders = new Order[1];
        arrayOrders = orders.toArray(arrayOrders);
        TradingRecord tradingRecord = new BaseTradingRecord(arrayOrders);
        
        TotalProfitCriterion totalProfit = new TotalProfitCriterion();
        System.out.println("Total profit: " + totalProfit.calculate(series, tradingRecord));
        // Average profit (per tick)
        System.out.println("Average profit (per tick): " + new AverageProfitCriterion().calculate(series, tradingRecord));
        // Number of trades
        System.out.println("Number of trades: " + new NumberOfTradesCriterion().calculate(series, tradingRecord));
        // Profitable trades ratio
        System.out.println("Profitable trades ratio: " + new AverageProfitableTradesCriterion().calculate(series, tradingRecord));
        // Maximum drawdown
        System.out.println("Maximum drawdown: " + new MaximumDrawdownCriterion().calculate(series, tradingRecord));
        // Reward-risk ratio
        System.out.println("Reward-risk ratio: " + new RewardRiskRatioCriterion().calculate(series, tradingRecord));
        // Total transaction cost
        System.out.println("Total transaction cost (from $1000): " + new LinearTransactionCostCriterion(1000, 0.005).calculate(series, tradingRecord));
        // Buy-and-hold
        System.out.println("Buy-and-hold: " + new BuyAndHoldCriterion().calculate(series, tradingRecord));
        // Total profit vs buy-and-hold
        System.out.println("Custom strategy profit vs buy-and-hold strategy profit: " + new VersusBuyAndHoldCriterion(totalProfit).calculate(series, tradingRecord));
    }
}
