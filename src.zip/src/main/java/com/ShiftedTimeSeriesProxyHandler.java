/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.ta4j.core.TimeSeries;

/**
 *
 * @author aanpilov
 */
public class ShiftedTimeSeriesProxyHandler implements InvocationHandler {
    private Logger log = LoggerFactory.getLogger(getClass());
    private TimeSeries base;    

    public ShiftedTimeSeriesProxyHandler(TimeSeries base) {
        this.base = base;        
    }
    
    @Override
    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {   
        if ("getTick".equals(method.getName())) {
            int index = (Integer)args[0];
            int shiftIndex = ((index + 1) > base.getEndIndex())?base.getEndIndex():(index + 1);
//            args[0] = shiftIndex;
            return base.getBar(shiftIndex);
        }        
        return method.invoke(base, args);        
    }
}
