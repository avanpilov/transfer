/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.scale;

import org.ta4j.core.TimeSeries;


/**
 *
 * @author aanpilov
 */
public interface ScaledTimeSeries extends TimeSeries {
    public void rebuild(int index);
}
