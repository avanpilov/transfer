/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.scale;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.time.ZonedDateTime;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import org.ta4j.core.Bar;
import org.ta4j.core.BaseBar;
import org.ta4j.core.BaseTimeSeries;
import org.ta4j.core.TimeSeries;
import org.ta4j.core.num.PrecisionNum;

/**
 *
 * @author aanpilov
 */
public class ScaledTimeSeriesProxyHandler implements InvocationHandler {
    private final TimeSeries base;
    private TimeSeries scaled;
    private final ChronoUnit scaleUnit;
    private final int scaleUnitCount = 1;

    public ScaledTimeSeriesProxyHandler(TimeSeries base, ChronoUnit scaleUnit) {
        this.base = base;
        this.scaleUnit = scaleUnit;
    }

    @Override
    public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
        if("rebuild".equals(method.getName())) {
            int index = (int) args[0];
            rebuild(index);
            return null;
        }
        
        return(scaled == null)? method.invoke(base, args) :  method.invoke(scaled, args);
    }
    
    private void rebuild(int index) {
        Map<ZonedDateTime, List<Bar>> subseries = base.getBarData().subList(0, index + 1).stream().collect(Collectors.groupingBy(tick -> tick.getBeginTime().truncatedTo(scaleUnit)));
        List<Bar> scaledTicks = subseries.keySet().stream().sorted().map(beginTime -> {
            List<Bar> childs = subseries.get(beginTime);            
            
            double open = childs.get(0).getOpenPrice().doubleValue();
            double high = childs.stream().mapToDouble(tick -> tick.getMaxPrice().doubleValue()).max().getAsDouble();
            double low = childs.stream().mapToDouble(tick -> tick.getMinPrice().doubleValue()).min().getAsDouble();
            double close = childs.get(childs.size() - 1).getClosePrice().doubleValue();
            double volume = childs.stream().mapToDouble(tick -> tick.getVolume().doubleValue()).sum();
            
            BaseBar tick = new BaseBar(beginTime.plus(scaleUnitCount, scaleUnit), open, high, low, close, volume, PrecisionNum::valueOf);
            return tick;
        }).collect(Collectors.toList());
        
        scaled = new BaseTimeSeries(scaledTicks);
    }    
}
