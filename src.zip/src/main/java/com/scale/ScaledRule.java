/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.scale;

import org.ta4j.core.Rule;
import org.ta4j.core.TradingRecord;
import org.ta4j.core.trading.rules.AbstractRule;


/**
 *
 * @author aanpilov
 */
public class ScaledRule extends AbstractRule {
    private final ScaledTimeSeries timeSeries;
    private final Rule baseRule;

    public ScaledRule(Rule baseRule, ScaledTimeSeries timeSeries) {
        this.timeSeries = timeSeries;
        this.baseRule = baseRule;
    }

    @Override
    public boolean isSatisfied(int index, TradingRecord tradingRecord) {
        timeSeries.rebuild(index);
        return baseRule.isSatisfied(timeSeries.getEndIndex(), tradingRecord);
    }
}
