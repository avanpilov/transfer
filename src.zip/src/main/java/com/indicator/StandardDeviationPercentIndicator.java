/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.indicator;

import org.ta4j.core.Indicator;
import org.ta4j.core.indicators.CachedIndicator;
import org.ta4j.core.indicators.SMAIndicator;
import org.ta4j.core.indicators.statistics.StandardDeviationIndicator;
import org.ta4j.core.num.Num;
import org.ta4j.core.num.PrecisionNum;

/**
 *
 * @author aanpilov
 */
public class StandardDeviationPercentIndicator extends CachedIndicator<Num> {
    private SMAIndicator sma;
    private StandardDeviationIndicator stdDev;

    public StandardDeviationPercentIndicator(Indicator<Num> indicator, int timeFrame) {
        super(indicator);
        sma = new SMAIndicator(indicator, timeFrame);
        stdDev = new StandardDeviationIndicator(indicator, timeFrame);
    }

    @Override
    protected Num calculate(int index) {
        return stdDev.getValue(index).dividedBy(sma.getValue(index)).multipliedBy(PrecisionNum.valueOf(100));
    }
    
    
}
